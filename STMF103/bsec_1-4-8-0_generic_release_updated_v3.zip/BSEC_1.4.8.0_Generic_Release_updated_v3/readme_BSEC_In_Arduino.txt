please refer to github 
https://github.com/BoschSensortec/BSEC-Arduino-library